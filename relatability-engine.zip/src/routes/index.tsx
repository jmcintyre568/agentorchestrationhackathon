import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";

const API_URL = "https://REPLACE-WITH-NGROK.ngrok-free.app/analyze";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Relatability Engine" },
      { name: "description", content: "Recruiter research dossier generator." },
    ],
  }),
  component: Index,
});

type Dossier = {
  summary: string;
  common_ground: { point: string; source_url: string }[];
  icebreakers: string[];
  smart_questions: string[];
  vibe: { style: string; how_to_mirror: string };
  resume_gaps: { gap: string; fix: string }[];
  trapdoor_project: string;
  evidence_ledger: { claim: string; source_url: string; confidence: "high" | "med" | "low" }[];
};

const STATUS_MESSAGES = [
  "Scouring LinkedIn footprints…",
  "Cross-referencing company news…",
  "Mining shared interests…",
  "Drafting icebreakers…",
  "Surfacing resume gaps…",
  "Weighing evidence…",
  "Assembling dossier…",
];

function Index() {
  const [form, setForm] = useState({
    recruiter_name: "",
    company: "",
    role: "",
    linkedin_url: "",
    resume_text: "",
  });
  const [loading, setLoading] = useState(false);
  const [statusIdx, setStatusIdx] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [dossier, setDossier] = useState<Dossier | null>(null);
  const [copied, setCopied] = useState(false);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (loading) {
      setStatusIdx(0);
      intervalRef.current = window.setInterval(() => {
        setStatusIdx((i) => (i + 1) % STATUS_MESSAGES.length);
      }, 2200);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [loading]);

  const update = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setDossier(null);
    setLoading(true);
    try {
      const ctrl = new AbortController();
      const timeout = setTimeout(() => ctrl.abort(), 95_000);
      const res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
        signal: ctrl.signal,
      });
      clearTimeout(timeout);
      if (!res.ok) throw new Error(`Request failed (${res.status})`);
      const data = (await res.json()) as Dossier;
      setDossier(data);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Something went wrong.";
      setError(msg.includes("aborted") ? "Request timed out after 90 seconds." : msg);
    } finally {
      setLoading(false);
    }
  };

  const copyMarkdown = async () => {
    if (!dossier) return;
    await navigator.clipboard.writeText(toMarkdown(dossier, form));
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-zinc-100">
      <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 sm:py-14">
        <header className="mb-10">
          <div className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-emerald-400/80">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
            Relatability Engine
          </div>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
            Walk into the interview knowing them better than they know you.
          </h1>
          <p className="mt-2 max-w-2xl text-sm text-zinc-400">
            Drop in the recruiter, the role, and your resume. Get a tactical dossier in under 90 seconds.
          </p>
        </header>

        {/* Form */}
        <form
          onSubmit={submit}
          className="rounded-2xl border border-zinc-800 bg-zinc-950/60 p-5 shadow-2xl shadow-black/40 backdrop-blur sm:p-7"
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Recruiter name" required>
              <input
                required
                value={form.recruiter_name}
                onChange={update("recruiter_name")}
                placeholder="Jane Doe"
                className={inputCls}
              />
            </Field>
            <Field label="Company" required>
              <input
                required
                value={form.company}
                onChange={update("company")}
                placeholder="Acme Inc."
                className={inputCls}
              />
            </Field>
            <Field label="Job role" required>
              <input
                required
                value={form.role}
                onChange={update("role")}
                placeholder="Senior Product Engineer"
                className={inputCls}
              />
            </Field>
            <Field label="LinkedIn URL (optional)">
              <input
                value={form.linkedin_url}
                onChange={update("linkedin_url")}
                placeholder="https://linkedin.com/in/…"
                className={inputCls}
              />
            </Field>
          </div>

          <div className="mt-4">
            <Field label="Resume (paste plain text)" required>
              <textarea
                required
                value={form.resume_text}
                onChange={update("resume_text")}
                rows={10}
                placeholder="Paste your resume here…"
                className={`${inputCls} font-mono text-xs leading-relaxed`}
              />
            </Field>
          </div>

          <div className="mt-6 flex flex-col items-stretch gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="text-xs text-zinc-500">
              POSTs to <code className="rounded bg-zinc-900 px-1.5 py-0.5 text-zinc-300">{API_URL}</code>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="group inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-500 px-5 py-2.5 text-sm font-medium text-zinc-950 transition hover:bg-emerald-400 disabled:cursor-not-allowed disabled:bg-zinc-800 disabled:text-zinc-400"
            >
              {loading ? (
                <>
                  <Spinner />
                  <span>{STATUS_MESSAGES[statusIdx]}</span>
                </>
              ) : (
                <>Analyze →</>
              )}
            </button>
          </div>
        </form>

        {error && (
          <div className="mt-6 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300">
            <strong className="font-semibold text-red-200">Error: </strong>
            {error}
          </div>
        )}

        {dossier && (
          <section className="mt-10 space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Dossier</h2>
              <button
                onClick={copyMarkdown}
                className="rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-1.5 text-xs font-medium text-zinc-200 transition hover:border-emerald-500/40 hover:text-emerald-300"
              >
                {copied ? "Copied ✓" : "Copy dossier as Markdown"}
              </button>
            </div>

            <Card title="Summary">
              <p className="text-sm leading-relaxed text-zinc-300">{dossier.summary}</p>
            </Card>

            <Card title="Common ground">
              <ul className="space-y-3">
                {dossier.common_ground.map((c, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm">
                    <Dot />
                    <div>
                      <p className="text-zinc-200">{c.point}</p>
                      <SourceLink url={c.source_url} />
                    </div>
                  </li>
                ))}
              </ul>
            </Card>

            <div className="grid gap-5 md:grid-cols-2">
              <Card title="Icebreakers">
                <ul className="space-y-2 text-sm text-zinc-300">
                  {dossier.icebreakers.map((s, i) => (
                    <li key={i} className="flex gap-2">
                      <span className="text-emerald-400">›</span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </Card>
              <Card title="Smart questions to ask">
                <ul className="space-y-2 text-sm text-zinc-300">
                  {dossier.smart_questions.map((s, i) => (
                    <li key={i} className="flex gap-2">
                      <span className="text-sky-400">?</span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            </div>

            <Card title="Vibe & mirroring">
              <div className="grid gap-4 sm:grid-cols-[140px_1fr]">
                <div className="text-xs uppercase tracking-wider text-zinc-500">Style</div>
                <div className="text-sm text-zinc-200">{dossier.vibe.style}</div>
                <div className="text-xs uppercase tracking-wider text-zinc-500">How to mirror</div>
                <div className="text-sm text-zinc-300">{dossier.vibe.how_to_mirror}</div>
              </div>
            </Card>

            <Card title="Resume gaps">
              <ul className="space-y-4">
                {dossier.resume_gaps.map((g, i) => (
                  <li key={i} className="rounded-lg border border-zinc-800 bg-zinc-900/60 p-3 text-sm">
                    <div className="text-amber-300">⚠ {g.gap}</div>
                    <div className="mt-1 text-zinc-300">
                      <span className="text-zinc-500">Fix: </span>
                      {g.fix}
                    </div>
                  </li>
                ))}
              </ul>
            </Card>

            <Card title="Trapdoor project" accent>
              <p className="text-sm leading-relaxed text-zinc-200">{dossier.trapdoor_project}</p>
            </Card>

            <Card title="Evidence ledger">
              <ul className="space-y-3">
                {dossier.evidence_ledger.map((e, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm">
                    <ConfidencePill level={e.confidence} />
                    <div className="flex-1">
                      <p className="text-zinc-200">{e.claim}</p>
                      <SourceLink url={e.source_url} />
                    </div>
                  </li>
                ))}
              </ul>
            </Card>
          </section>
        )}

        <footer className="mt-16 text-center text-xs text-zinc-600">
          Built for the conversation, not the interrogation.
        </footer>
      </div>
    </div>
  );
}

const inputCls =
  "w-full rounded-lg border border-zinc-800 bg-zinc-900/60 px-3 py-2 text-sm text-zinc-100 placeholder:text-zinc-600 focus:border-emerald-500/60 focus:outline-none focus:ring-2 focus:ring-emerald-500/20";

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-zinc-400">
        {label} {required && <span className="text-emerald-400">*</span>}
      </span>
      {children}
    </label>
  );
}

function Card({ title, children, accent }: { title: string; children: React.ReactNode; accent?: boolean }) {
  return (
    <div
      className={`rounded-2xl border bg-zinc-950/60 p-5 sm:p-6 ${
        accent ? "border-emerald-500/30 shadow-[0_0_40px_-20px_rgba(52,211,153,0.5)]" : "border-zinc-800"
      }`}
    >
      <h3 className="mb-3 text-xs font-semibold uppercase tracking-[0.18em] text-zinc-400">{title}</h3>
      {children}
    </div>
  );
}

function Spinner() {
  return (
    <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeOpacity="0.25" strokeWidth="4" />
      <path d="M4 12a8 8 0 018-8" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
    </svg>
  );
}

function Dot() {
  return <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-400" />;
}

function SourceLink({ url }: { url: string }) {
  if (!url) return null;
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="mt-1 inline-block break-all text-xs text-sky-400 hover:text-sky-300 hover:underline"
    >
      {url} ↗
    </a>
  );
}

function ConfidencePill({ level }: { level: "high" | "med" | "low" }) {
  const styles: Record<string, string> = {
    high: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
    med: "bg-amber-500/15 text-amber-300 border-amber-500/30",
    low: "bg-rose-500/15 text-rose-300 border-rose-500/30",
  };
  return (
    <span
      className={`inline-flex shrink-0 items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${styles[level] ?? styles.low}`}
    >
      {level}
    </span>
  );
}

function toMarkdown(d: Dossier, f: { recruiter_name: string; company: string; role: string }) {
  const lines: string[] = [];
  lines.push(`# Dossier: ${f.recruiter_name} — ${f.company} (${f.role})`, "");
  lines.push(`## Summary`, d.summary, "");
  lines.push(`## Common Ground`);
  d.common_ground.forEach((c) => lines.push(`- ${c.point}${c.source_url ? ` — [source](${c.source_url})` : ""}`));
  lines.push("", `## Icebreakers`);
  d.icebreakers.forEach((s) => lines.push(`- ${s}`));
  lines.push("", `## Smart Questions`);
  d.smart_questions.forEach((s) => lines.push(`- ${s}`));
  lines.push("", `## Vibe`, `- **Style:** ${d.vibe.style}`, `- **How to mirror:** ${d.vibe.how_to_mirror}`, "");
  lines.push(`## Resume Gaps`);
  d.resume_gaps.forEach((g) => lines.push(`- **${g.gap}** — ${g.fix}`));
  lines.push("", `## Trapdoor Project`, d.trapdoor_project, "");
  lines.push(`## Evidence Ledger`);
  d.evidence_ledger.forEach((e) =>
    lines.push(`- [${e.confidence.toUpperCase()}] ${e.claim}${e.source_url ? ` — [source](${e.source_url})` : ""}`),
  );
  return lines.join("\n");
}
